import   { BlogService } from './index'


BlogService.createPost()