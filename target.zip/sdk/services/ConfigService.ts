/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Config } from '../models/Config';
import type { Error } from '../models/Error';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class ConfigService {

    /**
     * Initial endpoint
     * Get basic configurations, also check for updates on mobile clients.
     * @param version Version of the web or mobile client.
     * @param platform Client platform.
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Config Successful operation
     * @returns Error Generic error
     * @throws ApiError
     */
    public static getConfig(
        version: string,
        platform: 'Web' | 'iOS' | 'Android',
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Config | Error> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/config',
            headers: {
                'Accept-Language': acceptLanguage,
            },
            query: {
                'version': version,
                'platform': platform,
            },
        });
    }

}
