/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Error } from '../models/Error';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class MediaService {

    /**
     * Image proxy
     * Image proxy service (like imgproxy, Thumbor etc.).
     * Provides on-demand crop, resizing and flipping of images and caching of them.
     * Check docs of service for detailed documentation.
     *
     * @param size Image size
     * @param imageUrl Url of raw image to manipulate.
     * @returns binary Successful operation
     * @returns Error Generic error
     * @throws ApiError
     */
    public static getSmart(
        size: string,
        imageUrl: string,
    ): CancelablePromise<Blob | Error> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/{size}/smart/{imageUrl}',
            path: {
                'size': size,
                'imageUrl': imageUrl,
            },
            errors: {
                401: `Unauthorized`,
                404: `The specified resource was not found`,
            },
        });
    }

    /**
     * Get Image
     * Get raw image from media service
     * @param image filename
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns binary Successful operation
     * @returns Error Generic error
     * @throws ApiError
     */
    public static getImage(
        image: string,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Blob | Error> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/media/{image}',
            path: {
                'image': image,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            errors: {
                401: `Unauthorized`,
                404: `The specified resource was not found`,
            },
        });
    }

}
