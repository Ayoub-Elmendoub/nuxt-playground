/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Device } from '../models/Device';
import type { Error } from '../models/Error';
import type { Token } from '../models/Token';
import type { UserDetailed } from '../models/UserDetailed';
import type { UserRegistration } from '../models/UserRegistration';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class UserService {

    /**
     * Register user
     * Start user registration process.
     * @param requestBody
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Error Generic error
     * @returns any Successful pre-registration
     * @throws ApiError
     */
    public static createUser(
        requestBody: UserRegistration,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Error | any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/user',
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                409: `Conflict`,
                422: `Invalid value`,
                429: `Too Many Attempts or Requests`,
            },
        });
    }

    /**
     * Verify user
     * User e-mail verification.
     * @param userId
     * @param verificationKey
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns any Successful verification
     * @returns Error Generic error
     * @throws ApiError
     */
    public static verifyUser(
        userId: string,
        verificationKey: string,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<any | Error> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/user/{userId}/verify/{verificationKey}',
            path: {
                'userId': userId,
                'verificationKey': verificationKey,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            errors: {
                422: `Invalid value`,
            },
        });
    }

    /**
     * Request password reset
     * Initiate a password reset flow.
     * @param requestBody
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns any Successful password change request
     * @returns Error Generic error
     * @throws ApiError
     */
    public static forgotPassword(
        requestBody: {
            email?: string;
        },
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<any | Error> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/user/forgot',
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                429: `Too Many Attempts or Requests`,
            },
        });
    }

    /**
     * Reset password
     * Create new password with reset key.
     * @param userId
     * @param resetKey
     * @param requestBody New password
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns any Successful password change
     * @returns Error Generic error
     * @throws ApiError
     */
    public static resetPassword(
        userId: string,
        resetKey: string,
        requestBody: {
            password?: string;
        },
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<any | Error> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/user/{userId}/reset/{resetKey}',
            path: {
                'userId': userId,
                'resetKey': resetKey,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                422: `Invalid value`,
                429: `Too Many Attempts or Requests`,
            },
        });
    }

    /**
     * Login with username and password
     * Login with credentials passed with basic auth.
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Token Successful login, access token
     * @returns Error Generic error
     * @throws ApiError
     */
    public static login(
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Token | Error> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/user/auth/login',
            headers: {
                'Accept-Language': acceptLanguage,
            },
            errors: {
                422: `Invalid value`,
                429: `Too Many Attempts or Requests`,
            },
        });
    }

    /**
     * Google Sign-in
     * Login with Google,
     * More details: https://developers.google.com/identity/sign-in/web/backend-auth
     * @param requestBody
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Token Successful login, access token
     * @returns Error Generic error
     * @throws ApiError
     */
    public static loginGoogle(
        requestBody: {
            id_token?: string;
        },
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Token | Error> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/user/auth/google',
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                401: `Unauthorized`,
            },
        });
    }

    /**
     * Facebook Sign-in
     * Login with Facebook,
     * More details: https://developers.facebook.com/docs/facebook-login/access-tokens/
     *
     * @param requestBody
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Token Successful login, access token
     * @returns Error Generic error
     * @throws ApiError
     */
    public static loginFacebook(
        requestBody: {
            user_id?: string;
            access_token?: string;
        },
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Token | Error> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/user/auth/facebook',
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                401: `Unauthorized`,
            },
        });
    }

    /**
     * Get user details
     * Get user & basic settings info
     * @param userId
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns UserDetailed UserDetailed object
     * @returns Error Generic error
     * @throws ApiError
     */
    public static getUser(
        userId: string,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<UserDetailed | Error> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/user/{userId}',
            path: {
                'userId': userId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            errors: {
                401: `Unauthorized`,
            },
        });
    }

    /**
     * Update user details
     * Change user basic settings (not the secure parts)
     * @param userId
     * @param requestBody
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns UserDetailed UserDetailed object
     * @returns Error Generic error
     * @throws ApiError
     */
    public static upadateUser(
        userId: string,
        requestBody: UserDetailed,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<UserDetailed | Error> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/user/{userId}',
            path: {
                'userId': userId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                401: `Unauthorized`,
            },
        });
    }

    /**
     * Update secure user details
     * Change user secure settings (e.g. change password)
     * @param userId
     * @param requestBody
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns UserDetailed UserDetailed object
     * @returns Error Generic error
     * @throws ApiError
     */
    public static upadateUserSecure(
        userId: string,
        requestBody: UserDetailed,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<UserDetailed | Error> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/user/{userId}/secure',
            path: {
                'userId': userId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                401: `Unauthorized`,
            },
        });
    }

    /**
     * Logout
     * Logout current user
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns any Successful logout
     * @returns Error Generic error
     * @throws ApiError
     */
    public static logout(
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<any | Error> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/user/auth/logout',
            headers: {
                'Accept-Language': acceptLanguage,
            },
            errors: {
                401: `Unauthorized`,
            },
        });
    }

    /**
     * Register user's device
     * Register new device token for push notification
     * @param userId
     * @param requestBody
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Error Generic error
     * @returns any Device created
     * @throws ApiError
     */
    public static postUserDevice(
        userId: string,
        requestBody: Device,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Error | any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/user/{userId}/device',
            path: {
                'userId': userId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                401: `Unauthorized`,
            },
        });
    }

}
