/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Comment } from '../models/Comment';
import type { Error } from '../models/Error';
import type { Post } from '../models/Post';
import type { PostDetailed } from '../models/PostDetailed';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class BlogService {

    /**
     * Get blog posts
     * Get posts list with filtering and pagination
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @param q Free text search.
     * @param sort Sort queries with direction (`+` ascending / `-` descending) and fields.
     *
     * @param fields Get only specific fields (or exclude them).
     * @param field Filter result collection by values of specific fields.
     * Generic name `field` is used in this definition, but it can be substituted with any field of the result schema.
     * Common operators for all field types (boolean, string, date, numeric):
     * - `.ne` - not equals
     * - `.eq` - equals
     * Numeric, date and string only operators:
     * - `.gt`- greater ( > )
     * - `.gte` - greater than (>=)
     * - `.lt` - less (<)
     * - `.lte` - less than (<=)
     * String only operators:
     * - `regex` - match regex expression
     * - `.cs` - contains substring
     * - `.ncs` - does not contain substring
     * - `.nregex` - does not match regular expression
     * E.g. `?createdAt[lt]=2020-06-10&updatedAt[lt]=2020-06-12`
     *
     * @param offset The number of items to skip before starting to collect the result set.
     * @param limit The numbers of items to return.
     * @returns Post Post objects
     * @returns Error Generic error
     * @throws ApiError
     */
    public static getPosts(
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
        q?: string,
        sort?: string,
        fields?: Array<string>,
        field?: string,
        offset?: number,
        limit: number = 20,
    ): CancelablePromise<Array<Post> | Error> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/blog/post',
            headers: {
                'Accept-Language': acceptLanguage,
                'Accept-Language': acceptLanguage,
            },
            query: {
                'q': q,
                'sort': sort,
                'fields': fields,
                'field': field,
                'offset': offset,
                'limit': limit,
            },
        });
    }

    /**
     * Create post
     * Create a new post to a blog with uploading images
     * @param formData Post to create
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Error Generic error
     * @returns PostDetailed Created post object
     * @throws ApiError
     */
    public static createPost(
        formData: {
            post?: PostDetailed;
            filename?: Array<Blob>;
        },
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Error | PostDetailed> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/blog/post',
            headers: {
                'Accept-Language': acceptLanguage,
            },
            formData: formData,
            mediaType: 'multipart/form-data',
            errors: {
                401: `Unauthorized`,
                403: `Unauthorized`,
            },
        });
    }

    /**
     * Get post
     * Get one post from blog
     * @param postId
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns PostDetailed Post object
     * @returns Error Generic error
     * @throws ApiError
     */
    public static getPost(
        postId: string,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<PostDetailed | Error> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/blog/post/{postId}',
            path: {
                'postId': postId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
        });
    }

    /**
     * Update post
     * Change post details
     * @param postId
     * @param requestBody Post to update
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns PostDetailed Post object
     * @returns Error Generic error
     * @throws ApiError
     */
    public static updatePost(
        postId: string,
        requestBody: PostDetailed,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<PostDetailed | Error> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/blog/post/{postId}',
            path: {
                'postId': postId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                401: `Unauthorized`,
                403: `Unauthorized`,
                404: `The specified resource was not found`,
            },
        });
    }

    /**
     * Remove post
     * Remove post from blog
     * @param postId
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Error Generic error
     * @throws ApiError
     */
    public static deletePost(
        postId: string,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Error> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/blog/post/{postId}',
            path: {
                'postId': postId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            errors: {
                401: `Unauthorized`,
                403: `Unauthorized`,
                404: `The specified resource was not found`,
            },
        });
    }

    /**
     * Get comments
     * Get list of comments that belongs to a post
     * @param postId
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @param q Free text search.
     * @param sort Sort queries with direction (`+` ascending / `-` descending) and fields.
     *
     * @param fields Get only specific fields (or exclude them).
     * @param field Filter result collection by values of specific fields.
     * Generic name `field` is used in this definition, but it can be substituted with any field of the result schema.
     * Common operators for all field types (boolean, string, date, numeric):
     * - `.ne` - not equals
     * - `.eq` - equals
     * Numeric, date and string only operators:
     * - `.gt`- greater ( > )
     * - `.gte` - greater than (>=)
     * - `.lt` - less (<)
     * - `.lte` - less than (<=)
     * String only operators:
     * - `regex` - match regex expression
     * - `.cs` - contains substring
     * - `.ncs` - does not contain substring
     * - `.nregex` - does not match regular expression
     * E.g. `?createdAt[lt]=2020-06-10&updatedAt[lt]=2020-06-12`
     *
     * @param offset The number of items to skip before starting to collect the result set.
     * @param limit The numbers of items to return.
     * @returns Comment Comment objects
     * @returns Error Generic error
     * @throws ApiError
     */
    public static getComments(
        postId: string,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
        q?: string,
        sort?: string,
        fields?: Array<string>,
        field?: string,
        offset?: number,
        limit: number = 20,
    ): CancelablePromise<Array<Comment> | Error> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/blog/post/{postId}/comment',
            path: {
                'postId': postId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            query: {
                'q': q,
                'sort': sort,
                'fields': fields,
                'field': field,
                'offset': offset,
                'limit': limit,
            },
            errors: {
                401: `Unauthorized`,
            },
        });
    }

    /**
     * Create comment
     * Create a new comment
     * @param postId
     * @param requestBody
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Error Generic error
     * @returns any Created comment object
     * @throws ApiError
     */
    public static createComment(
        postId: string,
        requestBody: Comment,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Error | any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/blog/post/{postId}/comment',
            path: {
                'postId': postId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                401: `Unauthorized`,
            },
        });
    }

    /**
     * Update comment
     * Change comment details
     * @param postId
     * @param commentId
     * @param requestBody
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Comment Comment object
     * @returns Error Generic error
     * @throws ApiError
     */
    public static updateComment(
        postId: string,
        commentId: string,
        requestBody: Comment,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Comment | Error> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/blog/post/{postId}/comment/{commentId}',
            path: {
                'postId': postId,
                'commentId': commentId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            body: requestBody,
            mediaType: 'application/json',
            errors: {
                401: `Unauthorized`,
                404: `The specified resource was not found`,
            },
        });
    }

    /**
     * Remove comment
     * Remove a specific comment
     * @param postId
     * @param commentId
     * @param acceptLanguage `Accept-Language` header according to HTTP standards, it contains:
     * - `<language>`: locale identifier. Language tag, followed by an optional country or region variant subtags  (like `en-US` or `fr-CA`).
     * - `*`: any language wildcard.
     * - `;q=`: q-factor weights describing order of priority of values in a comma-separated list. (E.g. `en-US, en;q=0.9, fr-CH;q=0.8, fr;q=0.7, *;q=0.5`)
     *
     * @returns Error Generic error
     * @throws ApiError
     */
    public static deleteComment(
        postId: string,
        commentId: string,
        acceptLanguage: 'hu-HU' | 'en-US' = 'hu-HU',
    ): CancelablePromise<Error> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/blog/post/{postId}/comment/{commentId}',
            path: {
                'postId': postId,
                'commentId': commentId,
            },
            headers: {
                'Accept-Language': acceptLanguage,
            },
            errors: {
                401: `Unauthorized`,
                404: `The specified resource was not found`,
            },
        });
    }

}
