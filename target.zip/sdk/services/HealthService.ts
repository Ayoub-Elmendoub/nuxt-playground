/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Health } from '../models/Health';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class HealthService {

    /**
     * Health check
     * Get detailed info about server health status.
     * @param secure Secure key for accessing health info
     * @returns Health Service Healthy
     * @throws ApiError
     */
    public static getHealth(
        secure?: string,
    ): CancelablePromise<Health> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/health',
            query: {
                'secure': secure,
            },
            errors: {
                503: `Service Unhealthy`,
            },
        });
    }

}
