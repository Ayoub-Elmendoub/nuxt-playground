/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type User = {
    /**
     * Unique id
     */
    id?: string;
    username: string;
    email: string;
};

