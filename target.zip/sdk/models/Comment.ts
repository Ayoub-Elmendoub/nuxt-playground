/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { User_properties_id } from './User_properties_id';

export type Comment = {
    id?: User_properties_id;
    username?: string;
    postId: User_properties_id;
    createdAt?: string;
    updatedAt?: string;
    message?: string;
};

