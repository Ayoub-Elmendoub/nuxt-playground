/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type Error = {
    code: string;
    message: string;
    fields?: any;
};

