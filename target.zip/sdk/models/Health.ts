/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { HealthConnection } from './HealthConnection';

export type Health = {
    timestamp?: string;
    /**
     * Server uptime in milliseconds
     */
    uptime: number;
    /**
     * Named connection test for each db and other integrations
     */
    connections: Record<string, HealthConnection>;
};

