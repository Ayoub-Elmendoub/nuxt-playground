/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type HealthConnection = {
    timestamp: string;
    /**
     * true if connection check succeed
     */
    success: boolean;
    /**
     * Connection test duration in milliseconds
     */
    duration: number;
    /**
     * Status message, e.g. for describing errors
     */
    status?: string;
};

