/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type Config = {
    /**
     * Describe server version
     */
    version?: string;
    update?: {
        /**
         * false if upgrade recommended
         */
        recommended?: boolean;
        /**
         * true if upgrade mandatory
         */
        force?: boolean;
        /**
         * navigable URL
         */
        link?: string;
    };
    config?: Record<string, string>;
};

