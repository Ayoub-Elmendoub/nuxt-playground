/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { User } from './User';

export type UserDetailed = (User & {
    image?: string;
    firstName?: string;
    lastName?: string;
});

