/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Post } from './Post';

export type PostDetailed = (Post & {
    createdAt?: string;
    updatedAt?: string;
    content?: string;
});

