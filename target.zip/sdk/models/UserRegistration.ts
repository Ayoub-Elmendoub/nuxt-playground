/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type UserRegistration = {
    email?: string;
    firstName?: string;
    lastName?: string;
    password?: string;
};

