/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

/**
 * Bearer JWT token
 */
export type Token = {
    token?: string;
};

